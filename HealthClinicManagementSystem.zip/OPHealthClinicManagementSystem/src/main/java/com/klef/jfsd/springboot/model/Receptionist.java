package com.klef.jfsd.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="receptionist_table")
public class Receptionist 
{
	@Id
	  @Column(nullable = false,length = 200)
	  private String username;
	  @Column(nullable = false,length = 200)
	  private String password;
}
